create package body pkg_encrypt_decrypt as

   main_password  varchar2(32) := 'ThisIsTheSuperSe';

   free_password varchar2(10) := 'OpenSesame';

   enc_mode       number := dbms_crypto.encrypt_aes128 +

                            dbms_crypto.chain_cbc      +

                            dbms_crypto.pad_pkcs5;



    function enc_account_passwd(

       p_account_passwd in varchar2,

       p_account_name   in varchar2,

       p_unlock_code    in varchar2 default NULL)

      return varchar2 as

      swordfish            raw(256);

      swordfish_encrypted raw(256);

    begin

      if (p_unlock_code is null or p_unlock_code != free_password)     

      then

        return null;

      end if;

      swordfish := dbms_crypto.randombytes(16);

      swordfish_encrypted := dbms_crypto.encrypt(swordfish,

                                                  enc_mode,

                                                  utl_i18n.string_to_raw(

                                                    main_password,

                                                    'al32utf8'));
      insert into

         tab_dbms_crypto_secrets

      values (p_account_name, swordfish_encrypted);

return utl_encode.base64_encode(

  dbms_crypto.encrypt(

    utl_i18n.string_to_raw(

      p_account_passwd,

      'al32utf8'),

    enc_mode,

    swordfish));

 end;

    function dec_account_passwd(

       p_account_passwd in varchar2,

       p_account_name   in varchar2,

       p_unlock_code    in varchar2 default NULL)

      return varchar2 as

      swordfish raw(256);

    begin

      if (p_unlock_code is null or p_unlock_code != free_password)  

      then

         return null;

      end if;

       select

         dbms_crypto.decrypt(

            value2,

            enc_mode,

            utl_i18n.string_to_raw(

               main_password,

               'al32utf8'))

      into

         swordfish

      from

         tab_dbms_crypto_secrets

      where

         value1 = p_account_name;

      return utl_i18n.raw_to_char(

           dbms_crypto.decrypt(

              utl_encode.base64_decode(

                 p_account_passwd),

                 enc_mode,

                 swordfish),

              'al32utf8');

    end;

  end;
/

