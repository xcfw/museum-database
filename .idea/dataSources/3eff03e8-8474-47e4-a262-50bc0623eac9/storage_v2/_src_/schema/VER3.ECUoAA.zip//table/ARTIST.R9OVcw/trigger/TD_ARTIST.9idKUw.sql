create trigger TD_ARTIST
    after delete
    on ARTIST
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Artist  Painter on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="00024413", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Painter"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_60", FK_COLUMNS="Artist_ID" */
    UPDATE Painter
      SET
        /* %SetFK(Painter,NULL) */
        Painter.Artist_ID = NULL
      WHERE
        /* %JoinFKPK(Painter,:%Old," = "," AND") */
        Painter.Artist_ID = :old.Artist_ID;

    /* erwin Builtin Trigger */
    /* Artist  Sculptor on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Sculptor"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_59", FK_COLUMNS="Artist_ID" */
    UPDATE Sculptor
      SET
        /* %SetFK(Sculptor,NULL) */
        Sculptor.Artist_ID = NULL
      WHERE
        /* %JoinFKPK(Sculptor,:%Old," = "," AND") */
        Sculptor.Artist_ID = :old.Artist_ID;

    /* erwin Builtin Trigger */
    /* Artist  Participants on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Participants"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_57", FK_COLUMNS="Artist_ID" */
    UPDATE Participants
      SET
        /* %SetFK(Participants,NULL) */
        Participants.Artist_ID = NULL
      WHERE
        /* %JoinFKPK(Participants,:%Old," = "," AND") */
        Participants.Artist_ID = :old.Artist_ID;


-- erwin Builtin Trigger
END;
/

