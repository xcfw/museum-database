create trigger TI_ARTIST
    before insert
    on ARTIST
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* City  Artist on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="0000d7db", PARENT_OWNER="", PARENT_TABLE="City"
    CHILD_OWNER="", CHILD_TABLE="Artist"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_56", FK_COLUMNS="City_ID" */
    UPDATE Artist
      SET
        /* %SetFK(Artist,NULL) */
        Artist.City_ID = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM City
            WHERE
              /* %JoinFKPK(:%New,City," = "," AND") */
              :new.City_ID = City.City_ID
        ) 
        /* %JoinPKPK(Artist,:%New," = "," AND") */
         and Artist.Artist_ID = :new.Artist_ID;


-- erwin Builtin Trigger
END;
/

