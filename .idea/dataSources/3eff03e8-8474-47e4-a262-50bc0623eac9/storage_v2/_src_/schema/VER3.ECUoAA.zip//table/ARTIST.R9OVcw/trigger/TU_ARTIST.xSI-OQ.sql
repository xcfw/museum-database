create trigger TU_ARTIST
    after update
    on ARTIST
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* Artist  Painter on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="0003a322", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Painter"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_60", FK_COLUMNS="Artist_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.Artist_ID <> :new.Artist_ID
  THEN
    UPDATE Painter
      SET
        /* %SetFK(Painter,NULL) */
        Painter.Artist_ID = NULL
      WHERE
        /* %JoinFKPK(Painter,:%Old," = ",",") */
        Painter.Artist_ID = :old.Artist_ID;
  END IF;

  /* Artist  Sculptor on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Sculptor"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_59", FK_COLUMNS="Artist_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.Artist_ID <> :new.Artist_ID
  THEN
    UPDATE Sculptor
      SET
        /* %SetFK(Sculptor,NULL) */
        Sculptor.Artist_ID = NULL
      WHERE
        /* %JoinFKPK(Sculptor,:%Old," = ",",") */
        Sculptor.Artist_ID = :old.Artist_ID;
  END IF;

  /* Artist  Participants on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Participants"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_57", FK_COLUMNS="Artist_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.Artist_ID <> :new.Artist_ID
  THEN
    UPDATE Participants
      SET
        /* %SetFK(Participants,NULL) */
        Participants.Artist_ID = NULL
      WHERE
        /* %JoinFKPK(Participants,:%Old," = ",",") */
        Participants.Artist_ID = :old.Artist_ID;
  END IF;

  /* erwin Builtin Trigger */
  /* City  Artist on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="City"
    CHILD_OWNER="", CHILD_TABLE="Artist"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_56", FK_COLUMNS="City_ID" */
  SELECT count(*) INTO NUMROWS
    FROM City
    WHERE
      /* %JoinFKPK(:%New,City," = "," AND") */
      :new.City_ID = City.City_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    :new.City_ID IS NOT NULL AND
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Artist because City does not exist.'
    );
  END IF;


-- erwin Builtin Trigger
END;
/

