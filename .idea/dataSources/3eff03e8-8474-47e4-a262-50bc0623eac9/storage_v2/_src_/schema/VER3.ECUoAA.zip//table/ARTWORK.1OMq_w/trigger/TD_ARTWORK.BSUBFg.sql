create trigger TD_ARTWORK
    after delete
    on ARTWORK
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Artwork  Rarity on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="0000b1dd", PARENT_OWNER="", PARENT_TABLE="Artwork"
    CHILD_OWNER="", CHILD_TABLE="Rarity"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_40", FK_COLUMNS="Artwork_ID" */
    UPDATE Rarity
      SET
        /* %SetFK(Rarity,NULL) */
        Rarity.Artwork_ID = NULL
      WHERE
        /* %JoinFKPK(Rarity,:%Old," = "," AND") */
        Rarity.Artwork_ID = :old.Artwork_ID;


-- erwin Builtin Trigger
END;
/

