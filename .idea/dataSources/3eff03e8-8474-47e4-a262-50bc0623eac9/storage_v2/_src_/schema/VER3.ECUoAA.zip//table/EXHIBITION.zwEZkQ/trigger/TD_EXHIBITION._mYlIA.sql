create trigger TD_EXHIBITION
    after delete
    on EXHIBITION
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Exhibition  Participants on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0000e460", PARENT_OWNER="", PARENT_TABLE="Exhibition"
    CHILD_OWNER="", CHILD_TABLE="Participants"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_18", FK_COLUMNS="Exhibition_ID" */
    SELECT count(*) INTO NUMROWS
      FROM Participants
      WHERE
        /*  %JoinFKPK(Participants,:%Old," = "," AND") */
        Participants.Exhibition_ID = :old.Exhibition_ID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete Exhibition because Participants exists.'
      );
    END IF;


-- erwin Builtin Trigger
END;
/

