create trigger TRG_CHECK_DATES
    before insert or update
    on EXHIBITION
    for each row
BEGIN
  IF( :new.EXDATE <= SYSDATE )
  THEN
    RAISE_APPLICATION_ERROR( -20001, 
          'Invalid Exhibition Date: ExDate must be greater than the current date - value = ' || 
          to_char( :new.EXDATE, 'MM-DD-YYYY HH24:MI:SS' ) );
  END IF;

END;
/

