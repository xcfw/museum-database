create trigger TU_EXHIBITION
    after update
    on EXHIBITION
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* erwin Builtin Trigger */
  /* Exhibition  Participants on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00021661", PARENT_OWNER="", PARENT_TABLE="Exhibition"
    CHILD_OWNER="", CHILD_TABLE="Participants"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_18", FK_COLUMNS="Exhibition_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.Exhibition_ID <> :new.Exhibition_ID
  THEN
    SELECT count(*) INTO NUMROWS
      FROM Participants
      WHERE
        /*  %JoinFKPK(Participants,:%Old," = "," AND") */
        Participants.Exhibition_ID = :old.Exhibition_ID;
    IF (NUMROWS > 0)
    THEN 
      raise_application_error(
        -20005,
        'Cannot update Exhibition because Participants exists.'
      );
    END IF;
  END IF;

  /* erwin Builtin Trigger */
  /* Place  Exhibition on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Place"
    CHILD_OWNER="", CHILD_TABLE="Exhibition"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_20", FK_COLUMNS="Place_ID" */
  SELECT count(*) INTO NUMROWS
    FROM Place
    WHERE
      /* %JoinFKPK(:%New,Place," = "," AND") */
      :new.Place_ID = Place.Place_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Exhibition because Place does not exist.'
    );
  END IF;


-- erwin Builtin Trigger
END;
/

