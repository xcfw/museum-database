create trigger TU_MATERIALS
    after update
    on MATERIALS
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* Materials  Sculptor on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="0000de7c", PARENT_OWNER="", PARENT_TABLE="Materials"
    CHILD_OWNER="", CHILD_TABLE="Sculptor"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_38", FK_COLUMNS="Material_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.Material_ID <> :new.Material_ID
  THEN
    UPDATE Sculptor
      SET
        /* %SetFK(Sculptor,NULL) */
        Sculptor.Material_ID = NULL
      WHERE
        /* %JoinFKPK(Sculptor,:%Old," = ",",") */
        Sculptor.Material_ID = :old.Material_ID;
  END IF;


-- erwin Builtin Trigger
END;
/

