create trigger TU_PAINT_TYPES
    after update
    on PAINT_TYPES
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* Paint_Types  Painter on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="0000e1df", PARENT_OWNER="", PARENT_TABLE="Paint_Types"
    CHILD_OWNER="", CHILD_TABLE="Painter"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_39", FK_COLUMNS="PaintType_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.PaintType_ID <> :new.PaintType_ID
  THEN
    UPDATE Painter
      SET
        /* %SetFK(Painter,NULL) */
        Painter.PaintType_ID = NULL
      WHERE
        /* %JoinFKPK(Painter,:%Old," = ",",") */
        Painter.PaintType_ID = :old.PaintType_ID;
  END IF;


-- erwin Builtin Trigger
END;
/

