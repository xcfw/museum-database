create trigger TI_PARTICIPANTS
    before insert
    on PARTICIPANTS
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Artist  Participants on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="00020c3c", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Participants"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_57", FK_COLUMNS="Artist_ID" */
    UPDATE Participants
      SET
        /* %SetFK(Participants,NULL) */
        Participants.Artist_ID = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM Artist
            WHERE
              /* %JoinFKPK(:%New,Artist," = "," AND") */
              :new.Artist_ID = Artist.Artist_ID
        ) 
        /* %JoinPKPK(Participants,:%New," = "," AND") */
         and Participants.Participant_ID = :new.Participant_ID;

    /* erwin Builtin Trigger */
    /* Exhibition  Participants on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Exhibition"
    CHILD_OWNER="", CHILD_TABLE="Participants"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_18", FK_COLUMNS="Exhibition_ID" */
    SELECT count(*) INTO NUMROWS
      FROM Exhibition
      WHERE
        /* %JoinFKPK(:%New,Exhibition," = "," AND") */
        :new.Exhibition_ID = Exhibition.Exhibition_ID;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */
      
      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert Participants because Exhibition does not exist.'
      );
    END IF;


-- erwin Builtin Trigger
END;
/

