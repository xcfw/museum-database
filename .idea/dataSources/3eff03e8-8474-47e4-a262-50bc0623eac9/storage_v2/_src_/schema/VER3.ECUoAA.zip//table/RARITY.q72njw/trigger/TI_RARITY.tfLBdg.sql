create trigger TI_RARITY
    before insert
    on RARITY
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Artwork  Rarity on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="0000eb7d", PARENT_OWNER="", PARENT_TABLE="Artwork"
    CHILD_OWNER="", CHILD_TABLE="Rarity"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_40", FK_COLUMNS="Artwork_ID" */
    UPDATE Rarity
      SET
        /* %SetFK(Rarity,NULL) */
        Rarity.Artwork_ID = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM Artwork
            WHERE
              /* %JoinFKPK(:%New,Artwork," = "," AND") */
              :new.Artwork_ID = Artwork.Artwork_ID
        ) 
        /* %JoinPKPK(Rarity,:%New," = "," AND") */
         and Rarity.Rarity_ID = :new.Rarity_ID;


-- erwin Builtin Trigger
END;
/

