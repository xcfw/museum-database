create trigger TU_RARITY
    after update
    on RARITY
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* erwin Builtin Trigger */
  /* Artwork  Rarity on child update no action */
  /* ERWIN_RELATION:CHECKSUM="0000f2f7", PARENT_OWNER="", PARENT_TABLE="Artwork"
    CHILD_OWNER="", CHILD_TABLE="Rarity"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_40", FK_COLUMNS="Artwork_ID" */
  SELECT count(*) INTO NUMROWS
    FROM Artwork
    WHERE
      /* %JoinFKPK(:%New,Artwork," = "," AND") */
      :new.Artwork_ID = Artwork.Artwork_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    :new.Artwork_ID IS NOT NULL AND
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Rarity because Artwork does not exist.'
    );
  END IF;


-- erwin Builtin Trigger
END;
/

