create trigger TI_SCULPTOR
    before insert
    on SCULPTOR
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Artist  Sculptor on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="0001f0aa", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Sculptor"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_59", FK_COLUMNS="Artist_ID" */
    UPDATE Sculptor
      SET
        /* %SetFK(Sculptor,NULL) */
        Sculptor.Artist_ID = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM Artist
            WHERE
              /* %JoinFKPK(:%New,Artist," = "," AND") */
              :new.Artist_ID = Artist.Artist_ID
        ) 
        /* %JoinPKPK(Sculptor,:%New," = "," AND") */
         and Sculptor.Sculptor_ID = :new.Sculptor_ID;

    /* erwin Builtin Trigger */
    /* Materials  Sculptor on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Materials"
    CHILD_OWNER="", CHILD_TABLE="Sculptor"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_38", FK_COLUMNS="Material_ID" */
    UPDATE Sculptor
      SET
        /* %SetFK(Sculptor,NULL) */
        Sculptor.Material_ID = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM Materials
            WHERE
              /* %JoinFKPK(:%New,Materials," = "," AND") */
              :new.Material_ID = Materials.Material_ID
        ) 
        /* %JoinPKPK(Sculptor,:%New," = "," AND") */
         and Sculptor.Sculptor_ID = :new.Sculptor_ID;


-- erwin Builtin Trigger
END;
/

