create trigger TU_SCULPTOR
    after update
    on SCULPTOR
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* erwin Builtin Trigger */
  /* Artist  Sculptor on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00020989", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Sculptor"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_59", FK_COLUMNS="Artist_ID" */
  SELECT count(*) INTO NUMROWS
    FROM Artist
    WHERE
      /* %JoinFKPK(:%New,Artist," = "," AND") */
      :new.Artist_ID = Artist.Artist_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    :new.Artist_ID IS NOT NULL AND
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Sculptor because Artist does not exist.'
    );
  END IF;

  /* erwin Builtin Trigger */
  /* Materials  Sculptor on child update no action */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Materials"
    CHILD_OWNER="", CHILD_TABLE="Sculptor"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_38", FK_COLUMNS="Material_ID" */
  SELECT count(*) INTO NUMROWS
    FROM Materials
    WHERE
      /* %JoinFKPK(:%New,Materials," = "," AND") */
      :new.Material_ID = Materials.Material_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    :new.Material_ID IS NOT NULL AND
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Sculptor because Materials does not exist.'
    );
  END IF;


-- erwin Builtin Trigger
END;
/

